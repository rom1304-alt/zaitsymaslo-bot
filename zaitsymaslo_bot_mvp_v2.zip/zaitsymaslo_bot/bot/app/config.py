from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    bot_token: str
    database_url: str
    managers_chat_id: int
    channel_url: str
    tz: str = "Europe/Moscow"
    admin_usernames: str = ""

    # Seller legal info (for оферта/политика)
    seller_name: str = "ИП Зайцев Роман Владимирович"
    brand_name: str = "Зайцы маслоделы"
    seller_inn: str = "645411352264"
    seller_ogrnip: str = "324237500079654"
    seller_address: str = "Краснодар, ул. Даниила Смоляна, д. 65к2, кв. 73"
    seller_phone: str = "+7918-099-0179"

    google_sheets_id: str | None = None
    google_service_account_file: str | None = None
    google_service_account_json: str | None = None  # raw JSON or base64

    class Config:
        env_file = ".env"
        extra = "ignore"

    @property
    def admin_usernames_set(self) -> set[str]:
        return {u.strip().lstrip("@").lower() for u in (self.admin_usernames or "").split(",") if u.strip()}

settings = Settings()
