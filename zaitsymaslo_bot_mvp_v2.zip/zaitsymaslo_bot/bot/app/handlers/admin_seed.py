from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy import select

from app.models import (
    City, CityDelivery, DeliveryMethod,
    StockLocation, StockLocationKind,
    PickupPoint,
    Category, Product, Variant,
    Stock,
    Role,
)
from app.services.delivery import DEFAULT_SLOTS
from app.services.money import fmt_rub

router = Router()

CATEGORIES = ["Масло", "Жмыхи", "Семена", "Бакалея", "Полуфабрикаты", "Овощи", "Фрукты", "Сладости"]

@router.message(Command("seed"))
async def seed(msg: Message, session, role):
    if role != Role.ADMIN:
        return await msg.answer("Недостаточно прав.")

    # Cities
    hk = (await session.execute(select(City).where(City.name == "Горячий Ключ"))).scalar_one_or_none()
    if not hk:
        hk = City(name="Горячий Ключ", active=True, meta={"timezone": "Europe/Moscow"})
        session.add(hk)

    krd = (await session.execute(select(City).where(City.name == "Краснодар"))).scalar_one_or_none()
    if not krd:
        krd = City(name="Краснодар", active=True, meta={"timezone": "Europe/Moscow"})
        session.add(krd)

    await session.commit()

    async def ensure_default_location(city: City, title: str, kind: StockLocationKind) -> StockLocation:
        loc = (await session.execute(
            select(StockLocation).where(
                StockLocation.city_id == city.id,
                StockLocation.is_default == True,
            )
        )).scalar_one_or_none()
        if not loc:
            loc = StockLocation(city_id=city.id, title=title, kind=kind, is_default=True, active=True)
            session.add(loc)
            await session.commit()
        return loc

    hk_loc = await ensure_default_location(hk, "Магазин (основной)", StockLocationKind.PICKUP_POINT)
    krd_loc = await ensure_default_location(krd, "Склад для отправок", StockLocationKind.WAREHOUSE)

    # Delivery schemes
    async def ensure_delivery(city: City, method: DeliveryMethod, rules: dict):
        cd = (await session.execute(
            select(CityDelivery).where(CityDelivery.city_id == city.id, CityDelivery.method == method)
        )).scalar_one_or_none()
        if not cd:
            cd = CityDelivery(city_id=city.id, method=method, enabled=True, rules=rules)
            session.add(cd)
        else:
            cd.enabled = True
            cd.rules = rules
        await session.commit()

    weekdays = [0, 1, 2, 3, 4]  # Mon-Fri
    await ensure_delivery(hk, DeliveryMethod.PICKUP, {"weekdays": weekdays})
    await ensure_delivery(hk, DeliveryMethod.COURIER, {"weekdays": weekdays, "slots": DEFAULT_SLOTS, "free_from_rub": 1000, "price_under_rub": 250})
    await ensure_delivery(krd, DeliveryMethod.COURIER, {"weekdays": weekdays, "slots": DEFAULT_SLOTS, "free_from_rub": 1000, "price_under_rub": 250})
    await ensure_delivery(krd, DeliveryMethod.PVZ_CDEK, {"note": "Стоимость по тарифам СДЭК — подтвердит менеджер"})
    await ensure_delivery(krd, DeliveryMethod.PVZ_OZON, {"note": "Стоимость по тарифам Озон — подтвердит менеджер"})

    # Pickup point HK (linked to hk_loc)
    pp = (await session.execute(
        select(PickupPoint).where(PickupPoint.city_id == hk.id, PickupPoint.address.like("%Калинина%"))
    )).scalar_one_or_none()
    if not pp:
        pp = PickupPoint(
            city_id=hk.id,
            location_id=hk_loc.id,
            title="Магазин",
            address="Калинина 23В",
            schedule="Пн–Пт 9:00–17:00",
            active=True,
        )
        session.add(pp)
        await session.commit()

    # Categories
    for title in CATEGORIES:
        c = (await session.execute(select(Category).where(Category.title == title))).scalar_one_or_none()
        if not c:
            session.add(Category(title=title, active=True))
    await session.commit()

    # Sample product in "Масло"
    cat_oil = (await session.execute(select(Category).where(Category.title == "Масло"))).scalar_one()
    prod = (await session.execute(select(Product).where(Product.title == "Масло (пример)"))).scalar_one_or_none()
    if not prod:
        prod = Product(
            category_id=cat_oil.id,
            title="Масло (пример)",
            description="Пример товара для теста бота. Замените на реальные позиции.",
            composition="Состав будет здесь.",
            shelf_life="6 месяцев",
            allergens="Возможны следы орехов/семян (пример).",
            photo_file_id=None,
            active=True,
        )
        session.add(prod)
        await session.commit()

    async def ensure_variant(label: str, ml: int, price_rub: int) -> Variant:
        v = (await session.execute(select(Variant).where(Variant.product_id == prod.id, Variant.label == label))).scalar_one_or_none()
        if not v:
            v = Variant(product_id=prod.id, label=label, volume_ml=ml, price_kop=price_rub * 100, active=True)
            session.add(v)
            await session.commit()
        return v

    v100 = await ensure_variant("100 мл", 100, 390)
    v250 = await ensure_variant("250 мл", 250, 790)
    v500 = await ensure_variant("500 мл", 500, 1290)

    async def ensure_stock(loc_id: int, var_id: int, qty: int):
        st = (await session.execute(select(Stock).where(Stock.location_id == loc_id, Stock.variant_id == var_id))).scalar_one_or_none()
        if not st:
            st = Stock(location_id=loc_id, variant_id=var_id, qty=qty)
            session.add(st)
        else:
            st.qty = qty
        await session.commit()

    # Example stock: HK has more, KRD less (edit later)
    await ensure_stock(hk_loc.id, v100.id, 20)
    await ensure_stock(hk_loc.id, v250.id, 15)
    await ensure_stock(hk_loc.id, v500.id, 10)

    await ensure_stock(krd_loc.id, v100.id, 5)
    await ensure_stock(krd_loc.id, v250.id, 5)
    await ensure_stock(krd_loc.id, v500.id, 3)

    await msg.answer(
        "Seed готов.\n"
        f"• Горячий Ключ: самовывоз + курьер ({', '.join(DEFAULT_SLOTS)})\n"
        "• Краснодар: курьер + ПВЗ СДЭК/Озон\n"
        "• Категории добавлены\n"
        "• Пример товара добавлен\n\n"
        "Дальше: /start → «Сделать заказ»"
    )
