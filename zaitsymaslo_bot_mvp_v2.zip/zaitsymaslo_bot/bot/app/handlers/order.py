from __future__ import annotations

from datetime import date
from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command

from sqlalchemy import select, delete
from sqlalchemy.orm import aliased

from app.config import settings
from app.keyboards.common import main_menu, inline_list, back_to_menu, contact_kb
from app.models import (
    City, Category, Product, Variant, Stock, StockLocation, PickupPoint, Cart, CartItem,
    CityDelivery, DeliveryMethod, PickupPoint,
    PromoCode, Order, OrderItem, OrderStatus
)
from app.states import OrderStates
from app.services.money import fmt_rub
from app.services.delivery import courier_cost_kop, next_working_dates, DEFAULT_SLOTS, is_weekday
from app.services import promo as promo_srv
from app.services.sheets import SheetsConfig, get_client, append_rows


async def _get_default_location_id(session, city_id: int) -> int:
    loc = (await session.execute(
        select(StockLocation).where(
            StockLocation.city_id==city_id,
            StockLocation.is_default==True,
            StockLocation.active==True
        )
    )).scalar_one_or_none()
    if not loc:
        # fallback: create a default warehouse if missing
        loc = StockLocation(city_id=city_id, title="Склад (по умолчанию)", is_default=True, active=True)
        session.add(loc)
        await session.commit()
    return loc.id

router = Router()

def _cb(prefix: str, value: int | str) -> str:
    return f"{prefix}:{value}"

async def _get_or_create_cart(session, tg_user_id: int, city_id: int) -> Cart:
    cart = (await session.execute(select(Cart).where(Cart.tg_user_id==tg_user_id))).scalar_one_or_none()
    if not cart:
        cart = Cart(tg_user_id=tg_user_id, city_id=city_id, promo_code=None)
        session.add(cart)
        await session.commit()
    else:
        cart.city_id = city_id
        cart.promo_code = None
        await session.execute(delete(CartItem).where(CartItem.cart_id==cart.id))
        await session.commit()
    return cart

async def _cart_summary(session, cart_id: int):
    # returns items list + subtotal
    q = (
        select(CartItem, Variant, Product)
        .join(Variant, Variant.id==CartItem.variant_id)
        .join(Product, Product.id==Variant.product_id)
        .where(CartItem.cart_id==cart_id)
    )
    rows = (await session.execute(q)).all()
    items = []
    subtotal = 0
    for ci, v, p in rows:
        line = v.price_kop * ci.qty
        subtotal += line
        items.append({
            "variant_id": v.id,
            "title": p.title,
            "variant": v.label,
            "qty": ci.qty,
            "price": v.price_kop,
            "line": line
        })
    return items, subtotal

async def _available_delivery_methods(session, city_id: int) -> list[DeliveryMethod]:
    rows = (await session.execute(select(CityDelivery).where(CityDelivery.city_id==city_id, CityDelivery.enabled==True))).scalars().all()
    return [r.method for r in rows]

def _delivery_title(m: DeliveryMethod) -> str:
    return {
        DeliveryMethod.PICKUP: "🏬 Самовывоз",
        DeliveryMethod.COURIER: "🚚 Курьер",
        DeliveryMethod.PVZ_CDEK: "📦 ПВЗ СДЭК",
        DeliveryMethod.PVZ_OZON: "📦 ПВЗ Озон",
    }[m]

@router.callback_query(F.data == "menu:order")
async def menu_order(cb: CallbackQuery, session, state: FSMContext):
    await state.clear()
    await cb.message.edit_text(
        "Введите ваш город (например: «Горячий Ключ» или «Краснодар»).",
        reply_markup=back_to_menu(),
    )
    await state.set_state(OrderStates.city_query)
    await cb.answer()

@router.message(OrderStates.city_query)
async def city_query(msg: Message, session, state: FSMContext):
    text = (msg.text or "").strip()
    if len(text) < 2:
        return await msg.answer("Введите минимум 2 буквы.")
    q = select(City).where(City.active==True, City.name.ilike(f"%{text}%")).limit(8)
    cities = (await session.execute(q)).scalars().all()
    if not cities:
        return await msg.answer("Не нашёл такой город. Попробуйте ещё раз.")
    items = [(c.name, _cb("city", c.id)) for c in cities]
    await msg.answer("Выберите город:", reply_markup=inline_list(items, cols=1, back_cb="menu:home"))

@router.callback_query(F.data.startswith("city:"))
async def city_choose(cb: CallbackQuery, session, state: FSMContext):
    city_id = int(cb.data.split(":",1)[1])
    city = (await session.execute(select(City).where(City.id==city_id))).scalar_one()
    cart = await _get_or_create_cart(session, cb.from_user.id, city_id)
    await state.update_data(city_id=city_id, cart_id=cart.id)
    await cb.message.edit_text(f"Город: <b>{city.name}</b>\n\nВыберите категорию:", reply_markup=await categories_kb(session))
    await state.set_state(OrderStates.browsing_categories)
    await cb.answer()

async def categories_kb(session):
    cats = (await session.execute(select(Category).where(Category.active==True).order_by(Category.title))).scalars().all()
    items = [(c.title, _cb("cat", c.id)) for c in cats]
    return inline_list(items, cols=2, back_cb="menu:home")

@router.callback_query(OrderStates.browsing_categories, F.data.startswith("cat:"))
async def category_choose(cb: CallbackQuery, session, state: FSMContext):
    cat_id = int(cb.data.split(":",1)[1])
    city_id = (await state.get_data()).get("city_id")
    # show products that have any stock in this city
    q = (
        select(Product)
        .where(Product.category_id==cat_id, Product.active==True)
        .order_by(Product.title)
    )
    prods = (await session.execute(q)).scalars().all()
    if not prods:
        await cb.answer("В этой категории пока нет товаров.")
        return
    items = [(p.title, _cb("prod", p.id)) for p in prods]
    await cb.message.edit_text("Выберите товар:", reply_markup=inline_list(items, cols=1, back_cb="order:cats"))
    await state.set_state(OrderStates.browsing_products)
    await cb.answer()

@router.callback_query(F.data=="order:cats")
async def back_to_cats(cb: CallbackQuery, session, state: FSMContext):
    data = await state.get_data()
    city_id = data.get("city_id")
    city = (await session.execute(select(City).where(City.id==city_id))).scalar_one()
    await cb.message.edit_text(f"Город: <b>{city.name}</b>\n\nВыберите категорию:", reply_markup=await categories_kb(session))
    await state.set_state(OrderStates.browsing_categories)
    await cb.answer()

@router.callback_query(OrderStates.browsing_products, F.data.startswith("prod:"))
async def product_choose(cb: CallbackQuery, session, state: FSMContext):
    prod_id = int(cb.data.split(":",1)[1])
    data = await state.get_data()
    city_id = data["city_id"]
    p = (await session.execute(select(Product).where(Product.id==prod_id))).scalar_one()
    # variants with stock > 0 for city
    q = (
        select(Variant, Stock)
        .join(Stock, (Stock.variant_id==Variant.id) & (Stock.location_id==city_id))
        .where(Variant.product_id==prod_id, Variant.active==True, Stock.qty>0)
        .order_by(Variant.volume_ml)
    )
    rows = (await session.execute(q)).all()
    if not rows:
        await cb.answer("Нет в наличии в этом городе.")
        return
    items = [(f"{v.label} — {fmt_rub(v.price_kop)} (остаток {st.qty})", _cb("var", v.id)) for v, st in rows]
    
    text = (
        f"<b>{p.title}</b>\n\n"
        f"{p.description}\n\n"
        f"<b>Состав:</b> {p.composition}\n"
        f"<b>Срок годности:</b> {p.shelf_life}\n"
        f"<b>Аллергены:</b> {p.allergens}\n\n"
        "Выберите фасовку:"
    )
    await state.update_data(product_id=prod_id)
    await cb.message.edit_text(text, reply_markup=inline_list(items, cols=1, back_cb="order:cats"))
    await state.set_state(OrderStates.choosing_variant)
    await cb.answer()

@router.callback_query(OrderStates.choosing_variant, F.data.startswith("var:"))
async def variant_choose(cb: CallbackQuery, session, state: FSMContext):
    var_id = int(cb.data.split(":",1)[1])
    await state.update_data(variant_id=var_id)
    kb = inline_list([(str(i), _cb("qty", i)) for i in [1,2,3,4,5]], cols=5, back_cb="order:cats")
    await cb.message.edit_text("Сколько штук добавить в корзину?", reply_markup=kb)
    await state.set_state(OrderStates.choosing_qty)
    await cb.answer()

@router.callback_query(OrderStates.choosing_qty, F.data.startswith("qty:"))
async def qty_choose(cb: CallbackQuery, session, state: FSMContext):
    qty = int(cb.data.split(":",1)[1])
    data = await state.get_data()
    city_id = data["city_id"]
    cart_id = data["cart_id"]
    var_id = data["variant_id"]

    # check stock
    loc_id = await _get_default_location_id(session, city_id)
    st = (await session.execute(select(Stock).where(Stock.location_id==loc_id, Stock.variant_id==var_id))).scalar_one_or_none()
    if not st or st.qty < qty:
        await cb.answer("Недостаточно на складе.")
        return

    ci = (await session.execute(select(CartItem).where(CartItem.cart_id==cart_id, CartItem.variant_id==var_id))).scalar_one_or_none()
    if not ci:
        ci = CartItem(cart_id=cart_id, variant_id=var_id, qty=qty)
        session.add(ci)
    else:
        if st.qty < ci.qty + qty:
            await cb.answer("Недостаточно на складе.")
            return
        ci.qty += qty
    await session.commit()
    await show_cart(cb, session, state, edit=True)

async def show_cart(obj, session, state: FSMContext, edit: bool):
    data = await state.get_data()
    cart_id = data["cart_id"]
    city_id = data["city_id"]
    city = (await session.execute(select(City).where(City.id==city_id))).scalar_one()
    items, subtotal = await _cart_summary(session, cart_id)
    if not items:
        text = "Корзина пуста. Выберите категорию:"
        kb = await categories_kb(session)
        if edit:
            await obj.message.edit_text(text, reply_markup=kb)
        else:
            await obj.answer(text, reply_markup=kb)
        await state.set_state(OrderStates.browsing_categories)
        return

    lines = [f"Город: <b>{city.name}</b>", "", "<b>Корзина:</b>"]
    for it in items:
        lines.append(f"• {it['title']} / {it['variant']} × {it['qty']} = {fmt_rub(it['line'])}")
    lines += ["", f"<b>Сумма:</b> {fmt_rub(subtotal)}"]

    promo_code = (await session.execute(select(Cart).where(Cart.id==cart_id))).scalar_one().promo_code
    if promo_code:
        lines.append(f"<b>Промокод:</b> {promo_code}")

    kb_items = [
        ("➕ Добавить ещё", "order:cats"),
        ("🏷 Ввести промокод", "cart:promo"),
        ("🚚 Оформить", "cart:checkout"),
        ("🧹 Очистить корзину", "cart:clear"),
        ("⬅️ В меню", "menu:home"),
    ]
    kb = inline_list(kb_items, cols=1)
    text = "\n".join(lines)
    if edit:
        await obj.message.edit_text(text, reply_markup=kb)
    else:
        await obj.answer(text, reply_markup=kb)
    await state.set_state(OrderStates.cart_view)

@router.callback_query(F.data=="cart:clear")
async def cart_clear(cb: CallbackQuery, session, state: FSMContext):
    data = await state.get_data()
    cart_id = data.get("cart_id")
    if cart_id:
        await session.execute(delete(CartItem).where(CartItem.cart_id==cart_id))
        cart = (await session.execute(select(Cart).where(Cart.id==cart_id))).scalar_one()
        cart.promo_code = None
        await session.commit()
    await cb.answer("Корзина очищена.")
    await back_to_cats(cb, session, state)

@router.callback_query(F.data=="cart:promo")
async def cart_promo(cb: CallbackQuery, state: FSMContext):
    await cb.message.edit_text("Введите промокод одним сообщением:", reply_markup=inline_list([("⬅️ Назад", "cart:back")], cols=1))
    await state.set_state(OrderStates.entering_promo)
    await cb.answer()

@router.callback_query(F.data=="cart:back")
async def cart_back(cb: CallbackQuery, session, state: FSMContext):
    await show_cart(cb, session, state, edit=True)
    await cb.answer()

@router.message(OrderStates.entering_promo)
async def promo_enter(msg: Message, session, state: FSMContext):
    code = (msg.text or "").strip().upper()
    data = await state.get_data()
    cart_id = data["cart_id"]
    if not code:
        return await msg.answer("Пустой промокод. Попробуйте ещё раз.")
    promo = (await session.execute(select(PromoCode).where(PromoCode.code==code))).scalar_one_or_none()
    if not promo:
        return await msg.answer("Не нашёл такой промокод. Попробуйте другой или нажмите «Назад».", reply_markup=inline_list([("⬅️ Назад", "cart:back")], cols=1))
    # Validate against current cart
    city = (await session.execute(select(City).where(City.id==data["city_id"]))).scalar_one()
    items, subtotal = await _cart_summary(session, cart_id)
    ok, reason = promo_srv.check_promo(promo, city_name=city.name, method="ANY", subtotal_kop=subtotal, today=date.today())
    if not ok:
        return await msg.answer(f"Промокод не подходит: {reason}", reply_markup=inline_list([("⬅️ Назад", "cart:back")], cols=1))

    cart = (await session.execute(select(Cart).where(Cart.id==cart_id))).scalar_one()
    cart.promo_code = code
    await session.commit()
    await msg.answer("Промокод применён ✅")
    # show cart again
    class Dummy: pass
    dummy = Dummy()
    dummy.message = msg
    await show_cart(dummy, session, state, edit=False)

@router.callback_query(F.data=="cart:checkout")
async def checkout_start(cb: CallbackQuery, session, state: FSMContext):
    data = await state.get_data()
    city_id = data["city_id"]
    methods = await _available_delivery_methods(session, city_id)
    items = [(_delivery_title(m), _cb("del", m.value)) for m in methods]
    await cb.message.edit_text("Выберите способ доставки:", reply_markup=inline_list(items, cols=1, back_cb="cart:back"))
    await state.set_state(OrderStates.choosing_delivery)
    await cb.answer()

@router.callback_query(OrderStates.choosing_delivery, F.data.startswith("del:"))
async def delivery_choose(cb: CallbackQuery, session, state: FSMContext):
    method = DeliveryMethod(cb.data.split(":",1)[1])
    await state.update_data(delivery_method=method.value)

    if method == DeliveryMethod.PICKUP:
        # choose pickup point
        data = await state.get_data()
        points = (await session.execute(select(PickupPoint).where(PickupPoint.city_id==data["city_id"], PickupPoint.active==True))).scalars().all()
        items = [(f"{p.title} — {p.address} ({p.schedule})", _cb("pp", p.id)) for p in points]
        await cb.message.edit_text("Выберите пункт самовывоза:", reply_markup=inline_list(items, cols=1, back_cb="cart:checkout"))
        await state.set_state(OrderStates.choosing_pickup_point)
        await cb.answer()
        return

    if method == DeliveryMethod.COURIER:
        # choose date (next 14 working days)
        dates = next_working_dates(date.today(), 14)
        items = [(d.strftime("%d.%m"), _cb("dt", d.isoformat())) for d in dates[:10]]
        await cb.message.edit_text("Выберите дату доставки (курьер):", reply_markup=inline_list(items, cols=5, back_cb="cart:checkout"))
        await state.set_state(OrderStates.choosing_courier_date)
        await cb.answer()
        return

    # PVZ - ask details; allow map link and location share
    await cb.message.edit_text(
        "Укажите ПВЗ:\n• отправьте адрес/код ПВЗ текстом\n• или отправьте геолокацию ПВЗ (кнопка «Поделиться геолокацией»)\n\nСтоимость доставки по тарифам ТК — подтвердит менеджер.",
        reply_markup=inline_list([("⬅️ Назад", "cart:checkout")], cols=1),
    )
    await state.set_state(OrderStates.entering_pvz)
    await cb.answer()

@router.callback_query(OrderStates.choosing_pickup_point, F.data.startswith("pp:"))
async def pickup_point_choose(cb: CallbackQuery, session, state: FSMContext):
    pp_id = int(cb.data.split(":",1)[1])
    await state.update_data(pickup_point_id=pp_id)

    # validate stock for this pickup point
    data = await state.get_data()
    cart_id = data.get("cart_id")
    pp = (await session.execute(select(PickupPoint).where(PickupPoint.id==pp_id))).scalar_one()
    # load cart items
    rows = (await session.execute(select(CartItem).where(CartItem.cart_id==cart_id))).scalars().all()
    insufficient = []
    for ci in rows:
        st = (await session.execute(select(Stock).where(Stock.location_id==pp.location_id, Stock.variant_id==ci.variant_id))).scalar_one_or_none()
        if not st or st.qty < ci.qty:
            insufficient.append(ci.variant_id)
    if insufficient:
        await cb.message.edit_text(
            "В выбранном пункте самовывоза недостаточно товара для текущей корзины. Попробуйте другой пункт или уменьшите количество.",
            reply_markup=inline_list([("⬅️ Назад в корзину","cart:back"),("🏬 Выбрать другой пункт","cart:checkout")], cols=1),
        )
        await cb.answer()
        return

    # pickup date: next working days only
    dates = next_working_dates(date.today(), 14)
    items = [(d.strftime("%d.%m"), _cb("pudt", d.isoformat())) for d in dates[:10]]
    await cb.message.edit_text("Выберите дату самовывоза:", reply_markup=inline_list(items, cols=5, back_cb="cart:checkout"))
    await state.set_state(OrderStates.choosing_courier_date)  # reuse date state
    await cb.answer()

@router.callback_query(OrderStates.choosing_courier_date, F.data.startswith("dt:"))
async def courier_date_choose(cb: CallbackQuery, state: FSMContext):
    iso = cb.data.split(":",1)[1]
    await state.update_data(delivery_date=iso, pickup_date=iso)
    # slots
    items = [(s, _cb("sl", i)) for i, s in enumerate(DEFAULT_SLOTS)]
    await cb.message.edit_text("Выберите слот времени:", reply_markup=inline_list(items, cols=1, back_cb="cart:checkout"))
    await state.set_state(OrderStates.choosing_courier_slot)
    await cb.answer()

@router.callback_query(OrderStates.choosing_courier_date, F.data.startswith("pudt:"))
async def pickup_date_choose(cb: CallbackQuery, state: FSMContext):
    iso = cb.data.split(":",1)[1]
    await state.update_data(delivery_date=iso)
    # no slots for pickup
    await cb.message.edit_text("Введите ваше имя:", reply_markup=inline_list([("⬅️ Назад", "cart:checkout")], cols=1))
    await state.set_state(OrderStates.entering_name)
    await cb.answer()

@router.callback_query(OrderStates.choosing_courier_slot, F.data.startswith("sl:"))
async def courier_slot_choose(cb: CallbackQuery, state: FSMContext):
    idx = int(cb.data.split(":",1)[1])
    await state.update_data(delivery_slot=DEFAULT_SLOTS[idx])
    await cb.message.edit_text("Введите адрес доставки (улица, дом, квартира):", reply_markup=inline_list([("⬅️ Назад", "cart:checkout")], cols=1))
    await state.set_state(OrderStates.entering_address)
    await cb.answer()

@router.message(OrderStates.entering_address)
async def address_enter(msg: Message, state: FSMContext):
    addr = (msg.text or "").strip()
    if len(addr) < 6:
        return await msg.answer("Адрес слишком короткий. Введите подробнее.")
    await state.update_data(address=addr)
    await msg.answer("Введите ваше имя:")
    await state.set_state(OrderStates.entering_name)

@router.message(OrderStates.entering_pvz)
async def pvz_enter(msg: Message, state: FSMContext):
    # accept text or location
    if msg.location:
        pvz = f"Геолокация: {msg.location.latitude:.6f},{msg.location.longitude:.6f}"
    else:
        pvz = (msg.text or "").strip()
    if not pvz:
        return await msg.answer("Не понял. Пришлите адрес/код ПВЗ или геолокацию.")
    await state.update_data(pvz_details=pvz)
    await msg.answer("Введите ваше имя:")
    await state.set_state(OrderStates.entering_name)

@router.message(OrderStates.entering_name)
async def name_enter(msg: Message, state: FSMContext):
    name = (msg.text or "").strip()
    if len(name) < 2:
        return await msg.answer("Введите имя.")
    await state.update_data(customer_name=name)
    await msg.answer("Теперь поделитесь контактом (телефон):", reply_markup=contact_kb())
    await state.set_state(OrderStates.waiting_contact)

@router.message(OrderStates.waiting_contact)
async def contact_wait(msg: Message, state: FSMContext):
    if not msg.contact or not msg.contact.phone_number:
        return await msg.answer("Нажмите кнопку «Поделиться контактом».")
    await state.update_data(phone=msg.contact.phone_number)
    await msg.answer("Комментарий к заказу (если не нужен — отправьте «-»):", reply_markup=None)
    await state.set_state(OrderStates.confirming)

@router.message(OrderStates.confirming)
async def confirm_step(msg: Message, session, state: FSMContext):
    comment = (msg.text or "").strip()
    if comment == "-":
        comment = None
    data = await state.get_data()
    cart_id = data["cart_id"]
    city_id = data["city_id"]
    method = DeliveryMethod(data["delivery_method"])
    items, subtotal = await _cart_summary(session, cart_id)

    if not items:
        return await msg.answer("Корзина пуста. Начните заново.", reply_markup=main_menu(settings.channel_url))

    # delivery cost
    delivery_cost = 0
    if method == DeliveryMethod.COURIER:
        delivery_cost = courier_cost_kop(subtotal)
    elif method in (DeliveryMethod.PVZ_CDEK, DeliveryMethod.PVZ_OZON):
        delivery_cost = 0  # unknown now, manager will уточнить

    # promo
    cart = (await session.execute(select(Cart).where(Cart.id==cart_id))).scalar_one()
    discount = 0
    if cart.promo_code:
        promo = (await session.execute(select(PromoCode).where(PromoCode.code==cart.promo_code))).scalar_one_or_none()
        if promo:
            city = (await session.execute(select(City).where(City.id==city_id))).scalar_one()
            ok, _ = promo_srv.check_promo(promo, city_name=city.name, method=method.value, subtotal_kop=subtotal, today=date.today())
            if ok:
                discount, delivery_cost = promo_srv.apply_promo(promo, subtotal_kop=subtotal, delivery_cost_kop=delivery_cost)

    total = max(0, subtotal + delivery_cost - discount)

    # agreement step
    summary_lines = ["<b>Проверьте заказ</b>"]
    for it in items:
        summary_lines.append(f"• {it['title']} / {it['variant']} × {it['qty']} = {fmt_rub(it['line'])}")
    summary_lines += ["", f"Сумма: <b>{fmt_rub(subtotal)}</b>"]
    if discount:
        summary_lines.append(f"Скидка: <b>-{fmt_rub(discount)}</b>")
    if method == DeliveryMethod.COURIER:
        summary_lines.append(f"Доставка (курьер): <b>{fmt_rub(delivery_cost)}</b>")
        summary_lines.append(f"Дата: <b>{data.get('delivery_date')}</b>, слот: <b>{data.get('delivery_slot')}</b>")
        summary_lines.append(f"Адрес: <b>{data.get('address')}</b>")
    elif method == DeliveryMethod.PICKUP:
        summary_lines.append("Доставка: <b>самовывоз</b>")
        summary_lines.append(f"Дата: <b>{data.get('delivery_date')}</b>")
    else:
        summary_lines.append(f"Доставка: <b>{_delivery_title(method)}</b>")
        summary_lines.append(f"ПВЗ: <b>{data.get('pvz_details')}</b>")
        summary_lines.append("Стоимость ТК: <b>уточнит менеджер</b>")
    summary_lines.append(f"Итого: <b>{fmt_rub(total)}</b>")
    if cart.promo_code:
        summary_lines.append(f"Промокод: <b>{cart.promo_code}</b>")
    summary_lines.append("")
    summary_lines.append("Нажимая «Подтвердить», вы соглашаетесь с обработкой персональных данных и условиями продажи. Документы: /legal")

    kb = inline_list([
        ("✅ Подтвердить заказ", "order:confirm"),
        ("⬅️ Назад в корзину", "cart:back"),
        ("❌ Отмена", "menu:home")
    ], cols=1)
    await msg.answer("\n".join(summary_lines), reply_markup=kb)
    await state.update_data(comment=comment, computed={"subtotal":subtotal,"delivery":delivery_cost,"discount":discount,"total":total})
    await state.set_state(OrderStates.confirming)

@router.callback_query(F.data=="order:confirm")
async def order_confirm(cb: CallbackQuery, session, state: FSMContext):
    data = await state.get_data()
    cart_id = data["cart_id"]
    city_id = data["city_id"]
    method = DeliveryMethod(data["delivery_method"])

    items, subtotal = await _cart_summary(session, cart_id)
    computed = data.get("computed") or {}
    delivery_cost = int(computed.get("delivery", 0))
    discount = int(computed.get("discount", 0))
    total = int(computed.get("total", subtotal + delivery_cost - discount))

    # create order
    order = Order(
        tg_user_id=cb.from_user.id,
        city_id=city_id,
        delivery_method=method,
        delivery_date=date.fromisoformat(data["delivery_date"]) if data.get("delivery_date") else None,
        delivery_slot=data.get("delivery_slot"),
        pickup_point_id=data.get("pickup_point_id"),
        address=data.get("address"),
        pvz_details=data.get("pvz_details"),
        customer_name=data.get("customer_name") or "—",
        phone=data.get("phone") or "—",
        comment=data.get("comment"),
        promo_code=(await session.execute(select(Cart).where(Cart.id==cart_id))).scalar_one().promo_code,
        discount_kop=discount,
        delivery_cost_kop=delivery_cost,
        total_kop=total,
        status=OrderStatus.NEW,
    )
    session.add(order)
    await session.commit()

    # create order items + decrement stock
    for it in items:
        session.add(OrderItem(
            order_id=order.id,
            variant_id=it["variant_id"],
            title=it["title"],
            variant_label=it["variant"],
            qty=it["qty"],
            price_kop=it["price"],
        ))
        st = (await session.execute(select(Stock).where(Stock.location_id==city_id, Stock.variant_id==it["variant_id"]))).scalar_one()
        st.qty = max(0, st.qty - it["qty"])
    await session.commit()

    # clear cart
    await session.execute(delete(CartItem).where(CartItem.cart_id==cart_id))
    cart = (await session.execute(select(Cart).where(Cart.id==cart_id))).scalar_one()
    cart.promo_code = None
    await session.commit()


    # write to Google Sheets (optional)
    try:
        if settings.google_sheets_id and (settings.google_service_account_file or settings.google_service_account_json):
            cfg = SheetsConfig(spreadsheet_id=settings.google_sheets_id, service_account_file=settings.google_service_account_file, service_account_json=settings.google_service_account_json)
            svc = get_client(cfg)
            city = (await session.execute(select(City).where(City.id==city_id))).scalar_one()
            # Orders sheet
            append_rows(svc, cfg.spreadsheet_id, "Orders!A1", [[
                order.id,
                str(order.created_at),
                city.name,
                order.delivery_method.value,
                str(order.delivery_date) if order.delivery_date else "",
                order.delivery_slot or "",
                str(order.pickup_point_id or ""),
                order.address or "",
                order.pvz_details or "",
                order.customer_name,
                order.phone,
                order.promo_code or "",
                order.discount_kop / 100.0,
                order.delivery_cost_kop / 100.0,
                order.total_kop / 100.0,
                order.status.value,
                order.manager_comment or "",
            ]])
            # Items sheet
            for it in items:
                append_rows(svc, cfg.spreadsheet_id, "Items!A1", [[
                    order.id,
                    it["variant_id"],
                    it["title"],
                    it["variant"],
                    it["qty"],
                    it["price"] / 100.0,
                    it["line"] / 100.0,
                ]])
    except Exception:
        pass

    # notify managers group
    try:
        city = (await session.execute(select(City).where(City.id==city_id))).scalar_one()
        text = [f"🆕 Новый заказ #{order.id}", f"Город: {city.name}", f"Способ: {_delivery_title(method)}"]
        if method == DeliveryMethod.COURIER:
            text += [f"Дата/слот: {order.delivery_date} / {order.delivery_slot}", f"Адрес: {order.address}"]
        elif method == DeliveryMethod.PICKUP:
            text += [f"Самовывоз: {order.delivery_date}"]
        else:
            text += [f"ПВЗ: {order.pvz_details}", "Стоимость ТК: уточнить"]
        text += [f"Контакт: {order.customer_name}, {order.phone}"]
        text += ["", "Состав заказа:"]
        for it in items:
            text.append(f"• {it['title']} / {it['variant']} × {it['qty']}")
        text += ["", f"Итого: {fmt_rub(order.total_kop)}"]
        await cb.bot.send_message(settings.managers_chat_id, "\n".join(text))
    except Exception:
        pass

    await cb.message.edit_text(
        f"Заказ <b>#{order.id}</b> оформлен ✅\n"
        "Менеджер свяжется с вами для подтверждения деталей.",
        reply_markup=main_menu(settings.channel_url),
    )
    await state.clear()
    await cb.answer()
