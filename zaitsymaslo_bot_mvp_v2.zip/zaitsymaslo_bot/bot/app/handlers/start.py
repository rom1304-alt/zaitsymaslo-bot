from __future__ import annotations
from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.keyboards.common import main_menu, back_to_menu, inline_list
from app.models import User, Role

router = Router()

async def ensure_user(session: AsyncSession, tg_id: int, username: str | None) -> User:
    u = (await session.execute(select(User).where(User.tg_id == tg_id))).scalar_one_or_none()
    if not u:
        u = User(tg_id=tg_id, username=(username or None), role=Role.VIEWER)
        session.add(u)
        await session.commit()
    else:
        if username and u.username != username:
            u.username = username
            await session.commit()
    # auto-promote by username list (first run convenience)
    if (username or "").lower() in settings.admin_usernames_set and u.role != Role.ADMIN:
        u.role = Role.ADMIN
        await session.commit()
    return u

@router.message(CommandStart())
async def start_cmd(msg: Message, session: AsyncSession):
    await ensure_user(session, msg.from_user.id, msg.from_user.username)
    await msg.answer(
        "Привет! Здесь можно оформить заказ.\n\nНажмите «Сделать заказ», чтобы начать.",
        reply_markup=main_menu(settings.channel_url),
    )

@router.callback_query(F.data == "menu:home")
async def home_cb(cb: CallbackQuery):
    await cb.message.edit_text(
        "Главное меню:",
        reply_markup=main_menu(settings.channel_url),
    )
    await cb.answer()

@router.callback_query(F.data == "menu:support")
async def support_cb(cb: CallbackQuery):
    await cb.message.edit_text(
        "Поддержка: напишите нам в ответ на это сообщение, и менеджер свяжется с вами.",
        reply_markup=back_to_menu(),
    )
    await cb.answer()

@router.message(Command("chatid"))
async def chatid(msg: Message):
    await msg.answer(f"chat_id = <code>{msg.chat.id}</code>")



@router.message(Command("legal"))
async def legal_menu(msg: Message):
    kb = inline_list([
        ("📄 Политика конфиденциальности", "legal:policy"),
        ("📄 Публичная оферта", "legal:offer"),
        ("⚠️ Аллергены", "legal:allergens"),
    ], cols=1)
    await msg.answer("Документы:", reply_markup=kb)

@router.callback_query(F.data.startswith("legal:"))
async def legal_show(cb: CallbackQuery):
    kind = cb.data.split(":",1)[1]
    seller = (
        f"<b>{settings.seller_name}</b> (бренд «{settings.brand_name}»)"
        f"\nИНН: {settings.seller_inn}"
        f"\nОГРНИП: {settings.seller_ogrnip}"
        f"\nАдрес: {settings.seller_address}"
        f"\nТел.: {settings.seller_phone}"
    )

    if kind == "allergens":
        text = (
            "⚠️ <b>Информация об аллергенах</b>\n"
            "В составе продукции могут присутствовать аллергены. "
            "Перед употреблением ознакомьтесь с составом. "
            "При индивидуальной непереносимости компонентов употребление не рекомендуется."
        )
    elif kind == "policy":
        text = (
            "📄 <b>Политика конфиденциальности (кратко)</b>\n\n"
            f"Оператор: {seller}\n\n"
            "Какие данные мы обрабатываем: имя, телефон, город/адрес доставки, сведения о заказе, промокод, комментарии к заказу.\n"
            "Цель: оформление, обработка и доставка заказа, связь с покупателем, исполнение обязательств, работа с обращениями.\n"
            "Правовое основание: согласие пользователя и необходимость исполнения договора купли-продажи.\n"
            "Кому можем передать: курьерским службам/транспортным компаниям — только данные, необходимые для доставки.\n"
            "Срок хранения: в течение срока, необходимого для обработки заказа и последующего учета/урегулирования обращений.\n"
            "Права пользователя: запросить уточнение/удаление данных через контакт продавца."
        )
    else:
        text = (
            "📄 <b>Публичная оферта (кратко)</b>\n\n"
            f"Продавец: {seller}\n\n"
            "Оформляя заказ в боте, покупатель направляет заявку на покупку товаров.\n"
            "Менеджер подтверждает заказ, а также стоимость доставки транспортными компаниями (СДЭК/Озон) при выборе ПВЗ.\n"
            "Самовывоз: бесплатно.\n"
            "Курьерская доставка: бесплатно при сумме заказа от 1000 ₽, иначе 250 ₽.\n"
            "Доставка в ПВЗ (СДЭК/Озон): стоимость по тарифам ТК, подтверждается менеджером.\n"
            "Оплата: по согласованию с менеджером.\n"
            "Условия возврата/обмена и иные детали предоставляются по запросу у продавца."
        )
    await cb.message.edit_text(text, reply_markup=back_to_menu())
    await cb.answer()
