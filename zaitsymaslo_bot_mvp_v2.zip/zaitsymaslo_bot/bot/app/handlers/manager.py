from __future__ import annotations
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy import select
from sqlalchemy.orm import joinedload

from app.models import Order, OrderStatus, Role, City

router = Router()

def _can_manage(role: Role) -> bool:
    return role in (Role.ADMIN, Role.MANAGER)

@router.message(Command("orders"))
async def orders(msg: Message, session, role):
    if not _can_manage(role):
        return await msg.answer("Недостаточно прав.")
    q = select(Order).order_by(Order.id.desc()).limit(20)
    orders = (await session.execute(q)).scalars().all()
    if not orders:
        return await msg.answer("Заказов пока нет.")
    # map city ids
    city_ids = list({o.city_id for o in orders})
    cities = {c.id: c.name for c in (await session.execute(select(City).where(City.id.in_(city_ids)))).scalars().all()}
    lines = ["Последние заказы:"]
    for o in orders:
        lines.append(f"• #{o.id} — {cities.get(o.city_id,'?')} — {o.delivery_method.value} — {o.status.value}")
    await msg.answer("\n".join(lines))

@router.message(Command("order"))
async def order_cmd(msg: Message, session, role):
    if not _can_manage(role):
        return await msg.answer("Недостаточно прав.")
    parts = (msg.text or "").split(maxsplit=3)
    if len(parts) < 4:
        return await msg.answer("Форматы:\n/order <id> status <STATUS>\n/order <id> comment <текст>")
    try:
        oid = int(parts[1])
    except:
        return await msg.answer("Некорректный id.")
    action = parts[2].lower()
    value = parts[3]

    o = (await session.execute(select(Order).where(Order.id==oid))).scalar_one_or_none()
    if not o:
        return await msg.answer("Заказ не найден.")

    if action == "status":
        try:
            st = OrderStatus(value.upper())
        except:
            return await msg.answer("Неверный статус.")
        o.status = st
        await session.commit()
        return await msg.answer(f"Заказ #{oid}: статус -> {st.value}")

    if action == "comment":
        o.manager_comment = value
        await session.commit()
        return await msg.answer(f"Заказ #{oid}: комментарий сохранён.")

    await msg.answer("Неизвестное действие. Используйте status/comment.")
