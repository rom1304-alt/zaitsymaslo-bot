from __future__ import annotations
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy import select

from app.models import User, Role

router = Router()

@router.message(Command("admin"))
async def admin_help(msg: Message, session, role):
    if role != Role.ADMIN:
        return await msg.answer("Недостаточно прав.")

    await msg.answer(
        "Админ-команды (MVP):\n\n• /seed — заполнить базовые города/доставку/категории + пример товара\n• /setrole @username ROLE — выдать роль (ADMIN/MANAGER/CATALOG/VIEWER)\n• /roles — список пользователей с ролями\n\nМенеджерские:\n\n• /orders — последние заказы\n• /order <id> status <STATUS>\n• /order <id> comment <текст>"
    )

@router.message(Command("setrole"))
async def setrole(msg: Message, session, role):
    if role != Role.ADMIN:
        return await msg.answer("Недостаточно прав.")
    parts = (msg.text or "").split()
    if len(parts) != 3:
        return await msg.answer("Формат: /setrole @username ROLE")
    username = parts[1].lstrip("@").lower()
    role_name = parts[2].upper()

    try:
        new_role = Role(role_name)
    except Exception:
        return await msg.answer("Роль должна быть ADMIN/MANAGER/CATALOG/VIEWER")

    u = (await session.execute(select(User).where(User.username.ilike(username)))).scalar_one_or_none()
    if not u:
        return await msg.answer("Пользователь не найден в базе. Пусть сначала напишет боту /start.")
    u.role = new_role
    await session.commit()
    await msg.answer(f"Готово. @{u.username} теперь {u.role.value}")

@router.message(Command("roles"))
async def roles_list(msg: Message, session, role):
    if role != Role.ADMIN:
        return await msg.answer("Недостаточно прав.")
    users = (await session.execute(select(User).order_by(User.role, User.username))).scalars().all()
    lines = ["Пользователи и роли:"]
    for u in users:
        lines.append(f"• @{u.username or '—'} ({u.tg_id}) — {u.role.value}")
    await msg.answer("\n".join(lines))
