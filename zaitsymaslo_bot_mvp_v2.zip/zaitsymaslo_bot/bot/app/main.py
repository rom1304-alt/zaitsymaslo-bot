import asyncio
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode

from app.config import settings
from app.models import Base
from app.db import engine
from app.middlewares.db import DbSessionMiddleware
from app.middlewares.role import RoleMiddleware

from app.handlers.start import router as start_router
from app.handlers.order import router as order_router
from app.handlers.admin import router as admin_router
from app.handlers.manager import router as manager_router
from app.handlers.admin_seed import router as seed_router

async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

async def main():
    await init_db()

    bot = Bot(settings.bot_token, parse_mode=ParseMode.HTML)
    dp = Dispatcher()

    dp.update.middleware(DbSessionMiddleware())
    dp.update.middleware(RoleMiddleware())

    dp.include_router(start_router)
    dp.include_router(order_router)
    dp.include_router(seed_router)
    dp.include_router(admin_router)
    dp.include_router(manager_router)

    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
