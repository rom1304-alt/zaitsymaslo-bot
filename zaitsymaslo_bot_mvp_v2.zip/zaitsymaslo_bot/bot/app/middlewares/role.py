from __future__ import annotations
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message, CallbackQuery
from sqlalchemy import select
from app.models import User, Role
from app.db import SessionLocal

class RoleMiddleware(BaseMiddleware):
    async def __call__(self, handler, event: TelegramObject, data: dict):
        tg_user = None
        if isinstance(event, Message):
            tg_user = event.from_user
        elif isinstance(event, CallbackQuery):
            tg_user = event.from_user

        role = Role.VIEWER
        if tg_user:
            async with SessionLocal() as s:
                u = (await s.execute(select(User).where(User.tg_id == tg_user.id))).scalar_one_or_none()
                if u:
                    role = u.role
        data["role"] = role
        return await handler(event, data)
