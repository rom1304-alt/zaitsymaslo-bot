from __future__ import annotations
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject
from app.db import SessionLocal

class DbSessionMiddleware(BaseMiddleware):
    async def __call__(self, handler, event: TelegramObject, data: dict):
        async with SessionLocal() as session:
            data["session"] = session
            return await handler(event, data)
