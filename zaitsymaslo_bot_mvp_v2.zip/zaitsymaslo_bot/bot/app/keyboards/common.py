from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

def main_menu(channel_url: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="🛒 Сделать заказ", callback_data="menu:order")
    kb.button(text="📦 Мои заказы", callback_data="menu:orders")
    kb.button(text="🆘 Поддержка", callback_data="menu:support")
    kb.button(text="📣 Наш канал", url=channel_url)
    kb.adjust(1)
    return kb.as_markup()

def back_to_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ В меню", callback_data="menu:home")]
    ])

def contact_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="📱 Поделиться контактом", request_contact=True)]],
        resize_keyboard=True,
        one_time_keyboard=True,
        selective=True,
    )

def inline_list(items: list[tuple[str, str]], *, cols: int = 1, back_cb: str | None = None) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    for text, cb in items:
        kb.button(text=text, callback_data=cb)
    if back_cb:
        kb.button(text="⬅️ Назад", callback_data=back_cb)
    kb.adjust(cols)
    return kb.as_markup()
