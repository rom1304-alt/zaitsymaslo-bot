def fmt_rub(kop: int) -> str:
    rub = kop // 100
    kk = abs(kop) % 100
    return f"{rub:,}".replace(",", " ") + f",{kk:02d} ₽"
