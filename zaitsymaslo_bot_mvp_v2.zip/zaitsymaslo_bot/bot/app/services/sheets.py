from __future__ import annotations
import base64, json
from dataclasses import dataclass
from typing import Optional

from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]

@dataclass
class SheetsConfig:
    spreadsheet_id: str
    service_account_file: str | None = None
    service_account_json: str | None = None  # raw JSON or base64

def _load_sa_info(raw: str) -> dict:
    raw = raw.strip()
    if raw.startswith("{"):
        return json.loads(raw)
    # assume base64
    decoded = base64.b64decode(raw).decode("utf-8")
    return json.loads(decoded)

def get_client(cfg: SheetsConfig):
    if cfg.service_account_json:
        info = _load_sa_info(cfg.service_account_json)
        creds = Credentials.from_service_account_info(info, scopes=SCOPES)
    else:
        if not cfg.service_account_file:
            raise ValueError("No service account provided")
        creds = Credentials.from_service_account_file(cfg.service_account_file, scopes=SCOPES)
    return build("sheets", "v4", credentials=creds)

def append_rows(service, spreadsheet_id: str, range_name: str, rows: list[list]):
    body = {"values": rows}
    service.spreadsheets().values().append(
        spreadsheetId=spreadsheet_id,
        range=range_name,
        valueInputOption="USER_ENTERED",
        insertDataOption="INSERT_ROWS",
        body=body,
    ).execute()
