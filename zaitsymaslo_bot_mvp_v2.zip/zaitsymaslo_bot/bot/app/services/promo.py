from __future__ import annotations
from datetime import date

def check_promo(promo, *, city_name: str, method: str, subtotal_kop: int, today: date) -> tuple[bool, str]:
    if not promo.active:
        return False, "Промокод не активен."
    if promo.valid_from and today < promo.valid_from:
        return False, "Промокод ещё не активен."
    if promo.valid_to and today > promo.valid_to:
        return False, "Срок действия промокода истёк."
    if promo.max_uses is not None and promo.used_count >= promo.max_uses:
        return False, "Лимит использований промокода исчерпан."

    cond = promo.conditions or {}
    if "min_total_rub" in cond and subtotal_kop < int(cond["min_total_rub"]) * 100:
        return False, "Сумма заказа меньше минимальной для промокода."
    if "cities" in cond and city_name not in cond["cities"]:
        return False, "Промокод недоступен в выбранном городе."
    if "delivery_methods" in cond and method not in cond["delivery_methods"]:
        return False, "Промокод не действует для выбранного способа доставки."
    return True, "OK"

def apply_promo(promo, *, subtotal_kop: int, delivery_cost_kop: int) -> tuple[int, int]:
    effects = promo.effects or {}
    discount = 0
    new_delivery = delivery_cost_kop

    if effects.get("free_delivery"):
        new_delivery = 0

    if "discount_percent" in effects:
        p = float(effects["discount_percent"])
        discount += int(subtotal_kop * (p / 100.0))

    if "discount_rub" in effects:
        discount += int(effects["discount_rub"]) * 100

    if discount > subtotal_kop:
        discount = subtotal_kop

    return discount, new_delivery
