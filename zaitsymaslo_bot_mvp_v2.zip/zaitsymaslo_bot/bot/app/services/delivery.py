from __future__ import annotations
from datetime import date, timedelta

DEFAULT_SLOTS = ["10:00–14:00", "14:00–18:00", "18:00–21:00"]

def courier_cost_kop(subtotal_kop: int) -> int:
    # free from 1000 RUB, else 250 RUB
    return 0 if subtotal_kop >= 1000 * 100 else 250 * 100

def is_weekday(d: date) -> bool:
    return d.weekday() < 5  # Mon-Fri

def next_working_dates(start: date, days: int = 14) -> list[date]:
    res: list[date] = []
    cur = start
    while len(res) < days:
        if is_weekday(cur):
            res.append(cur)
        cur += timedelta(days=1)
    return res
