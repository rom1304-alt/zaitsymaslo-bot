from aiogram.fsm.state import StatesGroup, State

class OrderStates(StatesGroup):
    city_query = State()
    browsing_categories = State()
    browsing_products = State()
    choosing_variant = State()
    choosing_qty = State()
    cart_view = State()
    entering_promo = State()
    choosing_delivery = State()
    choosing_pickup_point = State()
    choosing_courier_date = State()
    choosing_courier_slot = State()
    entering_address = State()
    entering_pvz = State()
    entering_name = State()
    waiting_contact = State()
    confirming = State()
