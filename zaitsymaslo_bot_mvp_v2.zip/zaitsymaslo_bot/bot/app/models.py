import enum
from datetime import datetime, date
from sqlalchemy import (
    String, Integer, Boolean, DateTime, ForeignKey, Enum, Text, Date, JSON, UniqueConstraint
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

class Base(DeclarativeBase):
    pass

class Role(str, enum.Enum):
    ADMIN = "ADMIN"
    MANAGER = "MANAGER"
    CATALOG = "CATALOG"
    VIEWER = "VIEWER"

class DeliveryMethod(str, enum.Enum):
    PICKUP = "PICKUP"
    COURIER = "COURIER"
    PVZ_CDEK = "PVZ_CDEK"
    PVZ_OZON = "PVZ_OZON"


class StockLocationKind(str, enum.Enum):
    PICKUP_POINT = "PICKUP_POINT"
    WAREHOUSE = "WAREHOUSE"

class StockLocation(Base):
    __tablename__ = "stock_locations"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    city_id: Mapped[int] = mapped_column(ForeignKey("cities.id"))
    title: Mapped[str] = mapped_column(String(160))
    kind: Mapped[StockLocationKind] = mapped_column(Enum(StockLocationKind), default=StockLocationKind.WAREHOUSE)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    city = relationship("City")
    location = relationship("StockLocation")

class OrderStatus(str, enum.Enum):
    NEW = "NEW"
    CONFIRMED = "CONFIRMED"
    IN_PROGRESS = "IN_PROGRESS"
    READY = "READY"
    SHIPPED = "SHIPPED"
    DONE = "DONE"
    CANCELED = "CANCELED"

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tg_id: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    role: Mapped[Role] = mapped_column(Enum(Role), default=Role.VIEWER)

class City(Base):
    __tablename__ = "cities"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    meta: Mapped[dict] = mapped_column(JSON, default=dict)

class CityDelivery(Base):
    __tablename__ = "city_deliveries"
    __table_args__ = (UniqueConstraint("city_id", "method", name="uq_city_method"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    city_id: Mapped[int] = mapped_column(ForeignKey("cities.id"))
    method: Mapped[DeliveryMethod] = mapped_column(Enum(DeliveryMethod))
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    rules: Mapped[dict] = mapped_column(JSON, default=dict)
    city = relationship("City")
    location = relationship("StockLocation")

class PickupPoint(Base):
    __tablename__ = "pickup_points"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    city_id: Mapped[int] = mapped_column(ForeignKey("cities.id"))
    location_id: Mapped[int] = mapped_column(ForeignKey("stock_locations.id"))
    title: Mapped[str] = mapped_column(String(160))
    address: Mapped[str] = mapped_column(String(255))
    schedule: Mapped[str] = mapped_column(String(255))
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    city = relationship("City")
    location = relationship("StockLocation")

class Category(Base):
    __tablename__ = "categories"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(120), unique=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)

class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id"))
    title: Mapped[str] = mapped_column(String(160))
    description: Mapped[str] = mapped_column(Text, default="")
    composition: Mapped[str] = mapped_column(Text, default="")
    shelf_life: Mapped[str] = mapped_column(String(120), default="")
    allergens: Mapped[str] = mapped_column(String(255), default="")
    photo_file_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    category = relationship("Category")

class Variant(Base):
    __tablename__ = "variants"
    __table_args__ = (UniqueConstraint("product_id", "label", name="uq_product_variant"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    label: Mapped[str] = mapped_column(String(64))  # 100 мл / 250 мл / 500 мл
    volume_ml: Mapped[int] = mapped_column(Integer)
    price_kop: Mapped[int] = mapped_column(Integer)  # price in kopeks
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    product = relationship("Product")

class Stock(Base):
    __tablename__ = "stock"
    __table_args__ = (UniqueConstraint("location_id", "variant_id", name="uq_location_variant_stock"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    location_id: Mapped[int] = mapped_column(ForeignKey("stock_locations.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    qty: Mapped[int] = mapped_column(Integer, default=0)


class PromoCode(Base):
    __tablename__ = "promocodes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    valid_from: Mapped[date | None] = mapped_column(Date, nullable=True)
    valid_to: Mapped[date | None] = mapped_column(Date, nullable=True)
    max_uses: Mapped[int | None] = mapped_column(Integer, nullable=True)
    per_user_limit: Mapped[int | None] = mapped_column(Integer, nullable=True)
    used_count: Mapped[int] = mapped_column(Integer, default=0)
    conditions: Mapped[dict] = mapped_column(JSON, default=dict)
    effects: Mapped[dict] = mapped_column(JSON, default=dict)

class Cart(Base):
    __tablename__ = "carts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tg_user_id: Mapped[int] = mapped_column(Integer, index=True)
    city_id: Mapped[int] = mapped_column(ForeignKey("cities.id"))
    promo_code: Mapped[str | None] = mapped_column(String(64), nullable=True)

class CartItem(Base):
    __tablename__ = "cart_items"
    __table_args__ = (UniqueConstraint("cart_id", "variant_id", name="uq_cart_variant"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    cart_id: Mapped[int] = mapped_column(ForeignKey("carts.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    qty: Mapped[int] = mapped_column(Integer)

class Order(Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    tg_user_id: Mapped[int] = mapped_column(Integer, index=True)
    city_id: Mapped[int] = mapped_column(ForeignKey("cities.id"))
    delivery_method: Mapped[DeliveryMethod] = mapped_column(Enum(DeliveryMethod))

    delivery_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    delivery_slot: Mapped[str | None] = mapped_column(String(64), nullable=True)

    pickup_point_id: Mapped[int | None] = mapped_column(ForeignKey("pickup_points.id"), nullable=True)
    address: Mapped[str | None] = mapped_column(String(255), nullable=True)
    pvz_details: Mapped[str | None] = mapped_column(String(255), nullable=True)

    customer_name: Mapped[str] = mapped_column(String(120))
    phone: Mapped[str] = mapped_column(String(64))
    comment: Mapped[str | None] = mapped_column(String(255), nullable=True)

    promo_code: Mapped[str | None] = mapped_column(String(64), nullable=True)
    discount_kop: Mapped[int] = mapped_column(Integer, default=0)
    delivery_cost_kop: Mapped[int] = mapped_column(Integer, default=0)
    total_kop: Mapped[int] = mapped_column(Integer, default=0)

    status: Mapped[OrderStatus] = mapped_column(Enum(OrderStatus), default=OrderStatus.NEW)
    manager_comment: Mapped[str | None] = mapped_column(String(255), nullable=True)

class OrderItem(Base):
    __tablename__ = "order_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"))
    variant_id: Mapped[int] = mapped_column(ForeignKey("variants.id"))
    title: Mapped[str] = mapped_column(String(255))
    variant_label: Mapped[str] = mapped_column(String(64))
    qty: Mapped[int] = mapped_column(Integer)
    price_kop: Mapped[int] = mapped_column(Integer)
